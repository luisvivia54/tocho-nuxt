<script setup lang="ts">
import { computed, ref, onMounted } from 'vue'
import { useNuxtApp } from '#app'
import { useAuthz } from '~/composables/useAuthz'

const { isAuthenticated, isAdmin } = useAuthz()
const { $kc, $kcReady, $kcGetToken } = useNuxtApp()

const isReady = computed(() => $kcReady?.value === true)
const isAuth  = computed(() => $kc?.authenticated === true)

const meData   = ref<any | null>(null)
const meError  = ref<string | null>(null)
const loadingMe = ref(false)

const login  = () => $kc?.login()
const logout = () => $kc?.logout({ redirectUri: window.location.origin })

const fetchMe = async () => {
  try {
    meError.value = null
    meData.value = null
    loadingMe.value = true

    if (!isReady.value) {
      meError.value = 'Keycloak aún no está listo.'
      return
    }

    if (!isAuth.value) {
      meError.value = 'Inicia sesión primero.'
      return
    }

    const token = await $kcGetToken()
    if (!token) {
      meError.value = 'No se pudo obtener el access token.'
      return
    }

    const res = await $fetch('http://tocho5-api.tochero5.mx/api/me', {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${token}`
      }
    })

    meData.value = res
  } catch (err: any) {
    console.error('Error /api/me:', err)
    const status =
      err?.response?._data?.status ||
      err?.status ||
      err?.response?.status
    const message =
      err?.response?._data?.message ||
      err?.statusMessage ||
      String(err)
    meError.value = `(${status ?? '??'}) ${message}`
  } finally {
    loadingMe.value = false
  }
}

onMounted(() => {
  if ($kc?.authenticated) {
    fetchMe()
  }
})

const showToken = async () => {
  const t = await $kcGetToken()
  alert(`Access token (primeros 60 chars):\n${t?.slice(0,60)}...`)
}
</script>

<template>
  <main style="padding:24px;font-family:Inter,system-ui,sans-serif">
    <h1>Nuxt + Keycloak · Demo</h1>

    <p v-if="!isReady">Inicializando sesión…</p>

    <div v-else>
      <p>Auth: <strong>{{ isAuth ? 'Sí' : 'No' }}</strong></p>
      <button v-if="isAuthenticated">Mi perfil</button>
      <button v-if="isAdmin">Panel Admin</button>

      <div v-if="!isAuth" style="margin-top:12px;">
        <button @click="login">Entrar con Keycloak</button>
      </div>

      <div v-else style="margin-top:12px;">
        <p>
          Usuario:
          <strong>{{ $kc?.tokenParsed?.preferred_username }}</strong>
        </p>

        <div style="margin-top:8px;">
          <button @click="showToken">Ver token</button>
          <button @click="logout" style="margin-left:8px">Salir</button>
        </div>

        <div style="margin-top:16px;">
          <button @click="fetchMe" :disabled="loadingMe">
            {{ loadingMe ? 'Consultando /api/me…' : 'Probar /api/me' }}
          </button>
        </div>

        <p
          v-if="meError"
          style="margin-top:8px;color:#dc2626;"
        >
          Error /api/me: {{ meError }}
        </p>

        <pre
          v-else-if="meData"
          style="margin-top:8px;background:#111827;color:#e5e7eb;padding:12px;border-radius:8px;font-size:12px;max-width:480px;overflow-x:auto;"
        >{{ meData }}</pre>
      </div>
    </div>

    <img
      src="https://pub-28868ec69a0c4ad7a136ec7f73f375c8.r2.dev/Captura%20de%20pantalla%202025-08-09%20a%20la(s)%208.52.45.png"
      alt="Captura pantalla"
      style="max-width: 300px; border-radius: 12px; margin-top:24px;"
    />
  </main>
</template>

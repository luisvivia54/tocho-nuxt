/// <reference types="@nuxt/telemetry" />
/// <reference types="@nuxt/devtools" />
/// <reference path="types/modules.d.ts" />
/// <reference path="types/runtime-config.d.ts" />
/// <reference path="types/app.config.d.ts" />
/// <reference types="nuxt" />
/// <reference types="../node_modules/.pnpm/@nuxt+vite-builder@4.2.1_magicast@0.5.1_nuxt@4.2.1_@parcel+watcher@2.5.1_@vue+compiler-_488cb09fc6b7b8e02b15c135ca8e62db/node_modules/@nuxt/vite-builder/dist/index.mjs" />
/// <reference types="/Users/luisvivia/Projects/tocho-nuxt-keycloak/node_modules/.pnpm/@nuxt+nitro-server@4.2.1_db0@0.3.4_ioredis@5.8.2_magicast@0.5.1_nuxt@4.2.1_@parcel+watc_d5af7941aa4f46a650d8bcc35336a7ac/node_modules/@nuxt/nitro-server/dist/index.mjs" />
/// <reference path="types/nitro-middleware.d.ts" />
/// <reference path="schema/nuxt.schema.d.ts" />

export {}

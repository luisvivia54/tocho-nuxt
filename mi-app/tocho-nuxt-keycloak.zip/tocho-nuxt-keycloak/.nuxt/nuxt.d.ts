/// <reference types="@nuxt/telemetry" />
/// <reference types="@nuxt/devtools" />
/// <reference path="types/builder-env.d.ts" />
/// <reference path="types/plugins.d.ts" />
/// <reference path="types/build.d.ts" />
/// <reference path="types/app.config.d.ts" />
/// <reference path="types/runtime-config.d.ts" />
/// <reference types="nuxt/app" />
/// <reference types="/Users/luisvivia/Projects/tocho-nuxt-keycloak/node_modules/.pnpm/@nuxt+nitro-server@4.2.1_db0@0.3.4_ioredis@5.8.2_magicast@0.5.1_nuxt@4.2.1_@parcel+watc_d5af7941aa4f46a650d8bcc35336a7ac/node_modules/@nuxt/nitro-server/dist/index.mjs" />
/// <reference types="vue-router" />
/// <reference path="types/middleware.d.ts" />
/// <reference path="types/nitro-middleware.d.ts" />
/// <reference path="types/layouts.d.ts" />
/// <reference path="types/components.d.ts" />
/// <reference path="imports.d.ts" />
/// <reference path="types/imports.d.ts" />
/// <reference path="schema/nuxt.schema.d.ts" />
/// <reference path="types/nitro.d.ts" />

export {}
